@extends('layouts.app')


@section('title', 'Dashboard')

@section('heading', 'Dashboard')

@section('content')


    @livewire('dashboard.dashboard')



@endsection
