@extends('layouts.app')
 

@section('title', 'Areas List')

@section('heading', 'Areas List')

@section('content')
 

@livewire('areas.areas') 



@endsection
