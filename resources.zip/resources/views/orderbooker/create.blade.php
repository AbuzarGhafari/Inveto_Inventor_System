@extends('layouts.app')

@section('heading', 'Add Order Booker')

@section('title', 'Add Order Booker')

@section('content') 
 
@livewire('orderbooker.order-booker-create') 


@endsection
