@extends('layouts.app')
 

@section('title', 'Shop Types List')

@section('heading', 'Shop Types List')

@section('content')
 

@livewire('shoptypes.shoptypes') 



@endsection
