@extends('layouts.app')

@section('title', 'Add Product')

@section('heading', 'Add Product')


@section('content')




@livewire('product.product-create')


@endsection
