@extends('layouts.app')
 

@section('title', 'Shops List')

@section('heading', 'Shops List')

@section('content')
 

@livewire('shop.shops')


@endsection
