@extends('layouts.app')

@section('title', 'Add Shop')

@section('heading', 'Add Shop')


@section('content')

@livewire('shop.shop-create')

@endsection
