@extends('layouts.app')
 

@section('title', 'Bills List')

@section('heading', 'Bills List')

@section('content')
 

@livewire('bills.bills') 



@endsection
