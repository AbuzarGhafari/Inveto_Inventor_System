<div>
    <input type="text" wire:model.live="name">
 
    Hi! My name is {{ $name }}
</div>