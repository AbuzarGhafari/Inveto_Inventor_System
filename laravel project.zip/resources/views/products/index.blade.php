@extends('layouts.app')

@section('heading', 'Products List')

@section('title', 'Products List')

@section('content')
 

@livewire('product.products')


@endsection
