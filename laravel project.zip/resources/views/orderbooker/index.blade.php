@extends('layouts.app')

@section('heading', 'Order Bookers List')

@section('title', 'Order Bookers List')

@section('content')
 

@livewire('orderbooker.order-bookers')
 

@endsection
